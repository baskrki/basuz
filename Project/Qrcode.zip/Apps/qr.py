import qrcode
from PIL import Image

img = qrcode.make('Yhttps://programmerbasu.github.io/bazucodez/')

img.save("basuCodez.png")#instead of sample.png you can write any name of your choice
